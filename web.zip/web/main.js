var express = require("express");
var app     = express();
var path    = require("path");


app.use(express.static(path.join(__dirname, 'public')));
app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/index.html'));
  //__dirname : It will resolve to your project folder.
});

app.get('/choclates',function(req,res){
  res.sendFile(path.join(__dirname+'/choclates.html'));
});
app.get('/products',function(req,res){
  res.sendFile(path.join(__dirname+'/products.html'));
});
app.get('/chips',function(req,res){
  res.sendFile(path.join(__dirname+'/chips.html'));
});
app.get('/biscuits',function(req,res){
  res.sendFile(path.join(__dirname+'/biscuits.html'));
});
app.get('/cooldrinks',function(req,res){
  res.sendFile(path.join(__dirname+'/cooldrinks.html'));
});
app.get('/tea',function(req,res){
  res.sendFile(path.join(__dirname+'/tea.html'));
});
app.get('/coffee',function(req,res){
  res.sendFile(path.join(__dirname+'/coffee.html'));
});
app.get('/noodles',function(req,res){
  res.sendFile(path.join(__dirname+'/noodles.html'));
});
app.listen(3000);

console.log("Running at Port 3000");